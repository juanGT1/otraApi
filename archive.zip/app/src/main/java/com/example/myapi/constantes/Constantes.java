package com.example.myapi.constantes;

public class Constantes {

    public static final String BASE_URL ="https://api.themoviedb.org/";
    public static final String API_KEY ="511174b10ded86a2c00770c3b55b5b88";



}
