package com.example.myapi.interfas;

import retrofit2.Call;

public interface Direccionmodelo {

    void leerpelis(String g);
}
