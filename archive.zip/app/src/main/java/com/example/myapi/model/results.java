package com.example.myapi.model;



public class results {

    DatosApi[] results ;

    public DatosApi[] getResults() {
        return results;

    }

    public void setResults(DatosApi[] results) {
        this.results = results;

    }





}
